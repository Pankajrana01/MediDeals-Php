<?php
$timeNow = time();
?>
<script src="<?= base_url('assets/ckeditor/ckeditor.js') ?>"></script>
<link rel="stylesheet" href="<?= base_url('assets/bootstrap-select-1.12.1/bootstrap-select.min.css') ?>">
<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <?php
        if ($this->session->flashdata('result_publish')) {
            ?> 
            <div class="alert alert-success"><?= $this->session->flashdata('result_publish') ?></div> 
            <?php
        }
        ?>
			<center><h1> Fetch All Vendors List </h1></center>
			<br/>
		<?php foreach($record as $values){?> 
        <div class="content">
            <form class="form-box" action="<?php echo base_url('admin/vendors/updatevendors/'.$values->id); ?>" method="POST" enctype="multipart/form-data">
         
                 
         
                    <div class="form-group"> 
                        <span>Name</span>
                        <input type="text" name="name" placeholder=" Name" value="<?php echo $values->name;?>" class="form-control">
                    </div> 
					<div class="form-group"> 
                      <span>Email</span> 
                        <input type="text" name="email" placeholder=" Email" value="<?php echo $values->email;?>" class="form-control">
                    </div>
					<div class="form-group"> 
                        <span>Firm Name</span>
                        <input type="text" name="firm_name" placeholder=" firm name" value="<?php echo $values->firm_name;?>" class="form-control">
                    </div>
					<div class="form-group"> 
                        <span>Firm Address</span>
                        <input type="text" name="firm_address" placeholder=" firm address" value="<?php echo $values->firm_address;?>" class="form-control">
                    </div>
					<div class="form-group"> 
                        <span>Drug License</span>
                        <input type="text" name="drug_licence" placeholder="drug license" value="<?php echo $values->drug_licence;?>" class="form-control">
                    </div>
					<div class="form-group"> 
                        <span>Fssia No</span>
                        <input type="text" name="fssai_no" placeholder="fssia no" value="<?php echo $values->fssai_no;?>" class="form-control">
                    </div>
					<div class="form-group"> 
                        <span>Contact Number</span>
                        <input type="text" name="contact_no" placeholder="contact no" value="<?php echo $values->contact_no;?>" class="form-control">
                    </div>
					<div class="form-group"> 
                        <span> Change Password</span>
                        <input type="text" name="password" placeholder=" Change password" value="<?php echo $values->password;?>" class="form-control">
                    </div>
                 
                
                
                <button type="submit" name="setProduct" class="btn btn-green">Update</button>
            </form> 
        </div>
    </div>
</div>
				<?php
}
?>
			
<!-- Modal Upload More Images -->

<script src="<?= base_url('assets/bootstrap-select-1.12.1/js/bootstrap-select.min.js') ?>"></script>
